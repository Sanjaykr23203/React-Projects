import React, { useState } from 'react';
import './App.css';

//requirement -> compare the string from 2 text boxes and print the each string and number of 
// time that string occured in  each text boxes, ignore the RegularExpressions and few text like(a, an, go the,etc) 
//and function that removes all printed values and text in textboxes(Clear button).

function App() {
  const [textbox1Value, setTextbox1Value] = useState('');
  const [textbox2Value, setTextbox2Value] = useState('');
  const [wordCounts, setWordCounts] = useState([]);

  const clearText = () => {
    setTextbox1Value('');
    setTextbox2Value('');
    setWordCounts([]);
  };

  const calculateWordCount = () => {
    const specialCharactersRegex = /[-“•/!@#$%^&*(),.?"':;{}|━<>”]/g;
    const ignoredWords = ['[',']','a', 'an', 'i', 'go', 'the', 'I', '━', '+', '-'];

    const wordsTextbox1 = textbox1Value.replace(specialCharactersRegex, ' ').trim().split(/\s+/).map(word => word.toLowerCase()).filter(word => !ignoredWords.includes(word));
    const wordsTextbox2 = textbox2Value.replace(specialCharactersRegex, ' ').trim().split(/\s+/).map(word => word.toLowerCase()).filter(word => !ignoredWords.includes(word));
    //removes duplicates
    const combinedWords = [...new Set([...wordsTextbox1, ...wordsTextbox2])];
    
  console.log(combinedWords);
     combinedWords.sort((wordA, wordB) => {
      const countA = wordsTextbox1.filter(w => w.toLowerCase() === wordA.toLowerCase()).length + wordsTextbox2.filter(w => w.toLowerCase() === wordA.toLowerCase()).length;
      const countB = wordsTextbox1.filter(w => w.toLowerCase() === wordB.toLowerCase()).length + wordsTextbox2.filter(w => w.toLowerCase() === wordB.toLowerCase()).length;
      return countB - countA; // Sort in descending order
    });

      setWordCounts(combinedWords.map(word => ({
      word: word,
      countTextbox1: wordsTextbox1.filter(w => w === word).length,
      countTextbox2: wordsTextbox2.filter(w => w === word).length
    })));
  };

  return (
    <>
    <div class="title">
    <h2>React Text Comparision App</h2>
    </div><br></br>
    <div className="container">
      <textarea value={textbox1Value} onChange={(e) => setTextbox1Value(e.target.value)} placeholder="Enter text in textbox1"/><br />
      <textarea value={textbox2Value} onChange={(e) => setTextbox2Value(e.target.value)} placeholder="Enter text in textbox2"/><br />
      <button onClick={clearText}>Clear</button>
      <button onClick={calculateWordCount}>Submit</button>
      <div className="table-section">
        <table>
          <thead>
            <tr>
              <th>Text</th>
              <th>Word Count in Textbox 1</th>
              <th>Word Count in Textbox 2</th>
            </tr>
          </thead>
           <tbody>
           {wordCounts.map((w,i)=>(
            <tr key={i}>
            <td>{w.word}</td>
            <td>{w.countTextbox1}</td>
            <td>{w.countTextbox2}</td>
            </tr>
  ))}
          </tbody>
        </table>
      </div>
    </div>
    </>
  );
}

export default App;
